# Exercise 2
Author: Laura V. Trujillo T [lvtrujillot@unal.edu.co](lvtrujillot@unal.edu.co)
- Use several of the tests that we have seen to compare those three distributions of data, with the aim of answering the following questions:
    1. Do they have the same mean?
    2. Do they have the same variance?
    3. Are they compatible with being the same distribution?
- Given the results obtained, discuss whether the tests actually provide the answers that are expected from them

# Statistics: Parametric and non-parametric hypotheses tests
                                    November 18, 2019
                        
 Author: Laura V. Trujillo T 
  
  [lvtrujillot@unal.edu.co](lvtrujillot@unal.edu.co)
  
## Abstract
This reports provides a comparison between three distributions in order to analyze their differences and similarities with the implementation of parametric and non-parametric tests. This allows us to characterize the data sets given despite the fact their statistical parameters such as mean, median and standard deviation are alike.

## Introduction

In statistics one of the paradigms to analyze the data is called _tail-test_ or _p-value test_. It consists basically in making the data falls in a distribution probability on the basis of a "null hypothesis" and concluding whether this hypothesis is false or not so false. This allows us to characterize a data set by its mean and variance but also to establish the similarity or distinctiveness of two or more samples of data by statistical tests.

1. Student's t- Test

     This test is computed when two distributions could possibly have the same variance but different means and  It is useful for measuring the significance of the difference of means [Press 1994](Press.com). For this test, one might stimates the standard error of the difference of means $s_D$ given by,
     
     $$s_D = \sqrt{\frac{\sum (x_i - \bar{x}_A)^2 + \sum (x_i - \bar{x}_B)^2}{N_A + N_B - 2 }\Bigg(\frac{1}{N_A} - \frac{1}{N_B} \Bigg)} $$
     
     $N_A, N_B$ are the number of points in the first and second data sets. Then, $t$ is computed as,
     
     $$t = \frac{\bar{x}_A - \bar{x}_B}{s_D} $$



2. F-Test

    This test evaluates the hypothesis of two data sets having different variances by trying to reject the null hypothesis that they are actually consistent. It is based on a gaussian distribution.
    
    $$ F = \frac{s_A^2}{s_B^2}, s_A >s_B $$
    
    It is used to determine whether means of data sets are equal.
    
    
3. Z-Test

    It is implemented when the variance of the samples are known in order to determine whether their means are different and it is assumed to have a normal distribution. In other words, Z-test represents how many standard deviations above or below the mean of the sample score by the test is.

4. Chi-Square Test

    

## Methodology


## Results

 Data | $\mu$  | $\mu_{1/2}$ | $\sigma^2$ | $\sigma$ | $Q_1$ | $Q_3$
---|--- | --- | --- | --- | ---| --- |
`dat1`| 1.9863 | 1.9759 | 2.0015 | 1.4147 |0.7467 | 3.2256|
`dat2`|1.9863 | 2.0000 | 2.0015 | 1.4147 |1.0000 | 3.0000|
`dat3`| 1.9863 | 2.0019 | 2.0015 | 1.4147 |1.0234| 2.9364|

## Conclusions




# Appendix: Coding Section


```R
#Resizing plots
library(repr) 
library(BSDA)
library(pracma)
options(repr.plot.width=5, repr.plot.height=5)
```


```R
# Data uploading
d1 <- read.table("dat1.dat", header=FALSE)
d2 <- read.table("dat2.dat", header=FALSE)
d3 <- read.table("dat3.dat", header=FALSE)
```

#### Do they have the same mean?
**Parametric test**
1. `t.test`


```R

```



**Non-parametric test of the mean**
1. Ranked`t.test`  & `wilcox.test`


```R
#Two samples Data 1 and Data 2 
x <- d1$V1
y <- d2$V1

# Ranks 
rank12 <- rank(c(x, y), ties.method="average") # Creating rank of data samples 1 & 2
ranked_x <- rank12[1:length(x)] # rank Ra 
ranked_y <- rank12[-(1:length(x))] #The other rank Rb
#ranked_y <- rank12[(length(x) + 1):length(y)]

#t-test with ranks
ttest12 <- t.test(ranked_x, ranked_y, mu=0)

# Wilcoxon test
wilcox12 <- wilcox.test(x, y, mu=0)

#Showing p-values for both test
rbind(wilcoxon = wilcox12$p.value, ttest = ttest12$p.value) # rbind combine r objects by rows 
```


<table>
<tbody>
	<tr><th scope=row>wilcoxon</th><td>0.009026857</td></tr>
	<tr><th scope=row>ttest</th><td>0.009023614</td></tr>
</tbody>
</table>




```R
# Two samples Data 2 and Data 3 (Poisson distribution and Gaussian distribution)
x <- d2$V1
y <- d3$V1

#parametric t-test 
ttest23 <- t.test(x, y, mu=0)

# non-parametric t-test
dat23 <- c(d2$V1, d3$V1)
rank23 <- rank(dat23, ties.method="average")
ranked_x <- rank23[1:length(x)]
ranked_y <- rank23[- (1:length(x))]

nttest23 = t.test(ranked_x, ranked_y, mu = 0)
#Wilcoxon test
wilcox23 <- wilcox.test(x, y, mu=0)
#p-values are:
rbind(wilcoxon=wilcox23$p.value, par.ttest=ttest23$p.value, non.par.ttest = nttest23$p.value)
```


<table>
<tbody>
	<tr><th scope=row>wilcoxon</th><td>2.958651e-05</td></tr>
	<tr><th scope=row>par.ttest</th><td>1.000000e+00</td></tr>
	<tr><th scope=row>non.par.ttest</th><td>2.948848e-05</td></tr>
</tbody>
</table>




```R
#Two samples Data1 & Data 3
x <- d1$V1
y <- d3$V1

#Ranked t.test
dat13 <- c(d1$V1, d3$V1)
rank13 <- rank(dat13, ties.method="average")
ranked_x <- rank13[1:length(x)]
ranked_y <- rank13[-(1:length(x))]

ttest13 <- t.test(ranked_x, ranked_y, mu=0)

#Wilcoxon test
wilcox13 <- wilcox.test(x,y, mu=0)

#p-values are:
rbind(wilcoxon=wilcox13$p.value, ttest=ttest13$p.value)
```


<table>
<tbody>
	<tr><th scope=row>wilcoxon</th><td>0.8614699</td></tr>
	<tr><th scope=row>ttest</th><td>0.8614740</td></tr>
</tbody>
</table>




```R
#Some test to figure out what a rank is.

dat12 <- c(d1$V1[0:3], d2$V1[0:3])
#dat12 =  2.7, 1.7, 0.6, 2, 4, 3
r1 <- rank(dat12, ties.method="average")
# 2, 1.7, 2.7, 0.6, 3, 4
#sort 3, 2, 4, 1, 6, 5 (ascending)
# rank 4, 2, 1, 3, 6, 5
rx <- r1[1:length(d1$V1[0:3])] #4, 2, 1
ry <- r1[- (1:length(d1$V1[0:3]))] # 3, 6, 5
#t.test(rx, ry)
```

#### Do they have the same variance?

**Parametric test**
1. `F-test`


```R
# F-test data1, data2 & data3 --- Assuming normal distribution
a <- d1$V1
b <- d2$V1
c <- d3$V1

ftest12 <- var.test(a, b)
ftest23 <- var.test(b, c)
ftest13 <- var.test(a, c)

nu1=length(d1$V1) - 1
nu2=length(d2$V1) - 1
nu3 = length(d3$V1) - 1

F12 = 2 * pf(ftest12$statistic, nu1, nu2)
F23 = 2 * pf(ftest23$statistic, nu2, nu3)
F13 = 2 * pf(ftest13$statistic, nu1, nu3)

#F-values
rbind(F1=F12, F2=F23, F3=F13)
#p-values 
rbind(ftest1=ftest12$p.value, ftest2=ftest23$p.value,ftest3=ftest13$p.value)
```


<table>
<thead><tr><th></th><th scope=col>F</th></tr></thead>
<tbody>
	<tr><th scope=row>F1</th><td>1</td></tr>
	<tr><th scope=row>F2</th><td>1</td></tr>
	<tr><th scope=row>F3</th><td>1</td></tr>
</tbody>
</table>




<table>
<tbody>
	<tr><th scope=row>ftest1</th><td>1</td></tr>
	<tr><th scope=row>ftest2</th><td>1</td></tr>
	<tr><th scope=row>ftest3</th><td>1</td></tr>
</tbody>
</table>



2. `z.test`


```R
ztest12 <- z.test(a, b, sigma.x=sd(a), sigma.y=sd(b))
ztest23 <- z.test(b, c, sigma.x=sd(b), sigma.y=sd(c))
ztest13 <- z.test(a, c, sigma.x=sd(a), sigma.y=sd(c))

# p -values
rbind(ztest1=ztest12$p.value, ztest2=ztest23$p.value, ztest3=ztest13$p.value)

#Z from expression
ma <- mean(a)
mb <- mean(b)
mc <- mean(c)

sa <- sd(a) ** 2 / length(a)
sb <- sd(b) ** 2 / length(b)
sc <- sd(c) ** 2 / length(c)

Z12 = (ma - mb) / sqrt(sa + sb)
Z23 = (mb - mc) / sqrt(sb + sc)
Z13 = (ma - mc) / sqrt(sa + sc)

rbind(Z1.pvalue=erfc(Z12), Z2.pvalue=erfc(Z23), Z3.pvalue=erfc(Z13) )
```


<table>
<tbody>
	<tr><th scope=row>ztest1</th><td>1</td></tr>
	<tr><th scope=row>ztest2</th><td>1</td></tr>
	<tr><th scope=row>ztest3</th><td>1</td></tr>
</tbody>
</table>




<table>
<tbody>
	<tr><th scope=row>Z1.pvalue</th><td>1</td></tr>
	<tr><th scope=row>Z2.pvalue</th><td>1</td></tr>
	<tr><th scope=row>Z3.pvalue</th><td>1</td></tr>
</tbody>
</table>



**Non parametric** `f.test`


```R
#----------   Ranks -------------
# Length data1 is equal for all data sets !
## Data 1 & Data 2
dat12 <- c(d1$V1, d2$V1)
rank12 <- rank(dat12, ties.method="average")
r1_x <- rank12[1:length(a)]
r1_y <- rank12[-(1:length(a))]

## Data 2 & Data 3
dat23 <- c(d2$V1, d3$V1)
rank23 <- rank(dat23, ties.method="average")
r2_x <- rank23[1:length(a)]
r2_y <- rank23[-(1:length(a))]

## Data 1 & Data 3
## Data 1 & Data 2
dat13<- c(d1$V1, d3$V1)
rank13 <- rank(dat13, ties.method="average")
r3_x <- rank13[1:length(a)]
r3_y <- rank13[-(1:length(a))]

#var.test
nftest12 = var.test(r1_x, r1_y)
nftest23 = var.test(r2_x, r2_y)
nftest13 = var.test(r3_x, r3_y)

rbind(non.ftest1 = nftest12$p.value, non.ftest2 = nftest23$p.value, non.ftest3 = nftest13$p.value)
```


<table>
<tbody>
	<tr><th scope=row>non.ftest1</th><td>0.000000e+00</td></tr>
	<tr><th scope=row>non.ftest2</th><td>1.695990e-02</td></tr>
	<tr><th scope=row>non.ftest3</th><td>1.820766e-14</td></tr>
</tbody>
</table>



#### Are they compatible with being the same distribution?

1. `K-S test`


```R
# Data 1 & Data2
ks12 <- ks.test(d1$V1, d2$V1)

# Data 2 & Data 3
ks23 <- ks.test(d2$V1, d3$V1)

# Data 1 & Data 3
ks13 <- ks.test(d1$V1, d3$V1)
```

    Warning message in ks.test(d1$V1, d2$V1):
    “p-value will be approximate in the presence of ties”Warning message in ks.test(d2$V1, d3$V1):
    “p-value will be approximate in the presence of ties”Warning message in ks.test(d1$V1, d3$V1):
    “p-value will be approximate in the presence of ties”

It seems like the warning is due to the implementation in R of `ks.test` expecting a continuous distribution. Nonetheles, K-S test works with both discrete and continuous. (This is just a _guess_)


```R
rbind(K.S1 = ks12$p.value, K.S2=ks23$p.value, K.S3=ks13$p.value)
rbind(D1= ks12$statistic, D2=ks23$statistic, D3=ks13$statistic)
```


<table>
<tbody>
	<tr><th scope=row>K.S1</th><td>0,000000e+00</td></tr>
	<tr><th scope=row>K.S2</th><td>0,000000e+00</td></tr>
	<tr><th scope=row>K.S3</th><td>1,110223e-16</td></tr>
</tbody>
</table>




<table>
<thead><tr><th></th><th scope=col>D</th></tr></thead>
<tbody>
	<tr><th scope=row>D1</th><td>0,1763</td></tr>
	<tr><th scope=row>D2</th><td>0,1804</td></tr>
	<tr><th scope=row>D3</th><td>0,0617</td></tr>
</tbody>
</table>



#### Plots


```R
png("boxplot.png", width=800, height=800)
boxplot(d1$V1, d2$V1, d3$V1, names=c("data 1","data 2","data 3"), col=rgb(0 , 0.5 , 0.8,alpha=0.25), border="brown")
grid()
dev.off()
```


<strong>png:</strong> 2


### `data1` 


```R
png("histd1.png", width=800, height=800)
hist(d1$V1, freq=FALSE, main="Data 1",ylim=c(0, 0.25), col=rgb(0 , 0.5 , 0.8,alpha=0.25),
     border="black",breaks = 10, xlab="V1", 
     xlim=c(-1,5))
curve(dunif(x, min=min(d1$V1), max=max(d1$V1)), from=-1, to=5, add=T, col="red", lw=2)
dev.off()
```


<strong>png:</strong> 2


### `data2`


```R
curpois <- dpois(x = 0:max(d2$V1), lambda = 1.5) 

hist(d2$V1, freq=FALSE, prob=TRUE, xlim=c(0, 8.0), ylim=c(0, 0.4), col=rgb(0 , 0.5 , 0.8,alpha=0.25), xlab="V1",
    breaks=rep(0:10,each=2.5)+c(-.3,.3))
points(0:max(d2$V1), curpois, pch=16, col=2) 
#curve(dnorm(x, mean = 2, sd = sqrt(2)),add = TRUE, col = 'red')
```


![png](output_29_0.png)


### `data3`


```R
png("histd3.png", width=800, height=800)
hist(d3$V1, freq=FALSE,main="Data 3", ylim=c(0, 0.35),col=rgb(0 , 0.5 , 0.8,alpha=0.25), xlab="V1")
curve(dnorm(x, mean=mean(d3$V1), sd=sd(d3$V1)), from=-4, to=8, add=T, col="red", lw=2)
dev.off()
```


<strong>png:</strong> 2


## Bibliography
[info](https://stackoverflow.com/questions/30061902/how-to-handle-citations-in-ipython-notebook)


```R

```
